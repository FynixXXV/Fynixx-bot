
import json
from .paths import data_root

DEFAULTS = {
    "name": "Fynix",
    "tone": "Descontraído",
    "humor": 70,
    "detail": 80,
    "personality": "",
    "ram_limit": "4 GB",
    "cpu_limit": 70,
    "disk_limit_gb": 20,
    "gpu": "Automática",
    "background_on_close": True,
    "internet": True,
    "files": True,
    "microphone": False,
    "camera": False,
    "run_programs": False,
    "destructive_without_confirmation": False,
    "roblox_bridge": False,
    "developer_mode": True,
    "knowledge_retrieval": True,
    "online_learning": False,
    "online_interval_min": 60,
    "auto_learning_requires_confirmation": True,
}

class SettingsStore:
    def __init__(self):
        self.path = data_root() / "settings.json"
        if not self.path.exists():
            self.save(DEFAULTS.copy())

    def load(self):
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
            out = DEFAULTS.copy()
            out.update(d)
            return out
        except Exception:
            return DEFAULTS.copy()

    def save(self, d):
        self.path.write_text(
            json.dumps(d, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
