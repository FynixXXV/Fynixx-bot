import ipaddress, json, socket
from html.parser import HTMLParser
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from datetime import datetime
from .knowledge import KnowledgeStore
from .paths import data_root

class TextParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]; self.depth=0
    def handle_starttag(self, tag, attrs):
        if tag.lower() in ('script','style','noscript','svg'): self.depth += 1
    def handle_endtag(self, tag):
        if tag.lower() in ('script','style','noscript','svg') and self.depth: self.depth -= 1
    def handle_data(self, data):
        if not self.depth:
            v=' '.join(data.split())
            if v: self.parts.append(v)

def _safe_url(url):
    p=urlparse(url)
    if p.scheme not in ('http','https') or not p.hostname:
        return False, 'somente http/https'
    host=p.hostname.lower()
    if host in {'localhost','localhost.localdomain'}:
        return False, 'host local bloqueado'
    try:
        infos=socket.getaddrinfo(host, p.port or (443 if p.scheme=='https' else 80), type=socket.SOCK_STREAM)
        for info in infos:
            ip=ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
                return False, 'endereço privado/local bloqueado'
    except Exception:
        return False, 'host não pôde ser validado'
    return True, ''

class OnlineLearner:
    def __init__(self, knowledge=None):
        self.knowledge=knowledge or KnowledgeStore()
        self.sources_path=data_root()/"learning_sources.json"
        self.events=data_root()/"learning_events.jsonl"
        if not self.sources_path.exists():
            self.sources_path.write_text(json.dumps({"urls":[]},ensure_ascii=False,indent=2),encoding='utf-8')

    def sources(self):
        try: return json.loads(self.sources_path.read_text(encoding='utf-8')).get('urls',[])
        except Exception: return []

    def add_source(self,url):
        ok,reason=_safe_url(url)
        if not ok: raise ValueError(reason)
        data=self.sources()
        if url not in data:
            data.append(url); self.sources_path.write_text(json.dumps({'urls':data},ensure_ascii=False,indent=2),encoding='utf-8')
        return len(data)

    def fetch(self,url,max_bytes=2_000_000):
        ok,reason=_safe_url(url)
        if not ok: raise ValueError(reason)
        req=Request(url,headers={'User-Agent':'FynixAI/3.0 KnowledgeLearner'})
        with urlopen(req,timeout=15) as r:
            raw=r.read(max_bytes+1)
            if len(raw)>max_bytes: raise ValueError('página excede o limite de tamanho')
            charset=r.headers.get_content_charset() or 'utf-8'
        parser=TextParser(); parser.feed(raw.decode(charset,errors='replace'))
        text=' '.join(parser.parts)
        return text[:120_000]

    def learn_url(self,url):
        text=self.fetch(url)
        title=urlparse(url).netloc
        result=self.knowledge.add_document(url,title,text)
        self._event('web_knowledge',{'url':url,**result})
        return result

    def learn_all(self):
        out=[]
        for url in self.sources():
            try: out.append({'url':url,**self.learn_url(url)})
            except Exception as exc: out.append({'url':url,'added':False,'error':str(exc)})
        return out

    def _event(self,kind,payload):
        with self.events.open('a',encoding='utf-8') as f:
            f.write(json.dumps({'kind':kind,'payload':payload,'created_at':datetime.now().isoformat(timespec='seconds')},ensure_ascii=False)+'\n')
