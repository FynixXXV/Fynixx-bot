import json, hashlib
from datetime import datetime
from .paths import data_root

class ContinuousLearning:
    """Turns explicit feedback into auditable learning events; negative feedback is review-only."""
    def __init__(self):
        self.path=data_root()/"feedback.json"
        self.events=data_root()/"learning_events.jsonl"
        if not self.path.exists(): self.path.write_text('[]',encoding='utf-8')

    def record(self,text,label,answer,positive):
        item={'id':hashlib.sha256(f'{text}|{answer}'.encode()).hexdigest()[:16],
              'text':text,'label':label,'answer':answer,'positive':bool(positive),
              'created_at':datetime.now().isoformat(timespec='seconds')}
        try: data=json.loads(self.path.read_text(encoding='utf-8'))
        except Exception: data=[]
        if not any(x.get('id')==item['id'] for x in data):
            data.append(item); self.path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
            with self.events.open('a',encoding='utf-8') as f:
                f.write(json.dumps({'kind':'feedback','payload':item},ensure_ascii=False)+'\n')
        return item

    def approved_examples(self):
        try: data=json.loads(self.path.read_text(encoding='utf-8'))
        except Exception: return []
        return [[x['label'],x['text'],x['answer']] for x in data if x.get('positive')]

    def stats(self):
        try: data=json.loads(self.path.read_text(encoding='utf-8'))
        except Exception: data=[]
        return {'total':len(data),'positive':sum(bool(x.get('positive')) for x in data),'negative':sum(not bool(x.get('positive')) for x in data)}
