
from pathlib import Path
import os

def data_root():
    local = os.environ.get("LOCALAPPDATA")
    p = Path(local) / "FynixAI" if local else Path(__file__).resolve().parent.parent / "data"
    p.mkdir(parents=True, exist_ok=True)
    return p

def ensure_dirs():
    base = data_root()
    for name in ("backups", "logs", "updates"):
        (base / name).mkdir(parents=True, exist_ok=True)
    return base
