
from PySide6.QtWidgets import QSystemTrayIcon, QMenu
from PySide6.QtGui import QAction

class TrayController:
    def __init__(self, window):
        self.window = window
        self.tray = QSystemTrayIcon(window)
        self.tray.setIcon(window.windowIcon())
        self.tray.setToolTip("Fynix AI")
        menu = QMenu()
        show = QAction("Mostrar Fynix")
        show.triggered.connect(self.show_window)
        exit_ = QAction("Sair do Fynix")
        exit_.triggered.connect(self.exit_app)
        menu.addAction(show)
        menu.addSeparator()
        menu.addAction(exit_)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self.activated)

    def activated(self, reason):
        if reason == QSystemTrayIcon.DoubleClick:
            self.show_window()

    def show(self):
        self.tray.show()

    def show_window(self):
        self.window._allow_close = False
        self.window.showNormal()
        self.window.raise_()
        self.window.activateWindow()

    def exit_app(self):
        self.window._allow_close = True
        self.window.close()
