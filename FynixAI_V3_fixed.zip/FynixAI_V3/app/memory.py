
import json
from .paths import data_root

class MemoryStore:
    def __init__(self):
        self.path = data_root() / "memory.json"
        if not self.path.exists():
            self.save({"facts": [], "preferences": {}, "project_notes": []})

    def load(self):
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {"facts": [], "preferences": {}, "project_notes": []}

    def save(self, data):
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def add_fact(self, fact):
        d = self.load()
        fact = fact.strip()
        if fact and fact not in d["facts"]:
            d["facts"].append(fact)
            self.save(d)
