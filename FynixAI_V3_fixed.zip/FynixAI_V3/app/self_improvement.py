
import json
from datetime import datetime
from .paths import data_root

class SelfImprovement:
    def __init__(self, brain):
        self.brain = brain
        self.log = data_root() / "brain" / "changelog.json"
        if not self.log.exists():
            self.log.write_text("[]", encoding="utf-8")

    def apply(self, examples):
        old, new = self.brain.self_improve(examples)
        try:
            entries = json.loads(self.log.read_text(encoding="utf-8"))
        except Exception:
            entries = []
        entries.append({
            "time": datetime.now().isoformat(timespec="seconds"),
            "from": old,
            "to": new,
            "examples_added": len(examples),
        })
        self.log.write_text(json.dumps(entries, ensure_ascii=False, indent=2), encoding="utf-8")
        return old, new
