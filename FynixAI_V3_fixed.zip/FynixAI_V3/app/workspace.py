
from pathlib import Path
import shutil
from datetime import datetime
from .paths import data_root

class Workspace:
    def __init__(self, root=None):
        self.root = Path(root).resolve() if root else None

    def set_root(self, root):
        self.root = Path(root).resolve()

    def list_files(self, limit=2000):
        if not self.root or not self.root.exists():
            return []
        try:
            return [p for p in self.root.rglob("*") if p.is_file()][:limit]
        except Exception:
            return []

    def read_text(self, path):
        p = Path(path).resolve()
        if not self.root or (p != self.root and self.root not in p.parents):
            raise PermissionError("Arquivo fora do workspace.")
        return p.read_text(encoding="utf-8", errors="replace")

    def backup(self, path):
        p = Path(path).resolve()
        dest_dir = data_root() / "backups"
        dest_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = dest_dir / f"{p.name}.{stamp}.bak"
        shutil.copy2(p, dest)
        return dest
