
import psutil
import subprocess

def gpu_names():
    names = []
    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=3
        )
        if out.returncode == 0:
            names = [x.strip() for x in out.stdout.splitlines() if x.strip()]
    except Exception:
        pass
    return names

def snapshot():
    vm = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    return {
        "ram_total": vm.total / 1024**3,
        "ram_used": vm.used / 1024**3,
        "ram_percent": vm.percent,
        "cpu_percent": psutil.cpu_percent(interval=0.1),
        "cpu_count": psutil.cpu_count(logical=True) or 1,
        "disk_free": disk.free / 1024**3,
        "disk_total": disk.total / 1024**3,
        "gpus": gpu_names()
    }

def try_set_cpu_affinity(max_logical_cpus):
    try:
        max_logical_cpus = max(1, int(max_logical_cpus))
        psutil.Process().cpu_affinity(list(range(min(max_logical_cpus, psutil.cpu_count()))))
        return True
    except Exception:
        return False
