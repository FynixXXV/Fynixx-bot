
from urllib.request import Request, urlopen
from html.parser import HTMLParser
from PySide6.QtCore import QThread, Signal

class TextParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.skip = False
    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript"):
            self.skip = True
    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript"):
            self.skip = False
    def handle_data(self, data):
        if not self.skip:
            value = " ".join(data.split())
            if value:
                self.parts.append(value)

class WebWorker(QThread):
    result = Signal(str, str)
    def __init__(self, urls):
        super().__init__()
        self.urls = urls

    def run(self):
        for url in self.urls:
            try:
                req = Request(url, headers={"User-Agent": "FynixAI/2.0"})
                with urlopen(req, timeout=10) as response:
                    raw = response.read(2_000_000).decode("utf-8", errors="replace")
                parser = TextParser()
                parser.feed(raw)
                text = " ".join(parser.parts)
                self.result.emit(url, text[:20_000])
            except Exception as exc:
                self.result.emit(url, f"ERRO: {exc}")
