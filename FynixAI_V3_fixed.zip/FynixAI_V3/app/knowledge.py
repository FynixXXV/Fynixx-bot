import hashlib, re, sqlite3
from datetime import datetime
from pathlib import Path
from .paths import data_root

TOKEN_RE = re.compile(r"[a-záàâãéêíóôõúç0-9_]+", re.I)

class KnowledgeStore:
    """Persistent local knowledge base with deterministic lexical retrieval."""
    def __init__(self):
        self.path = data_root() / "knowledge.db"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def _conn(self):
        c = sqlite3.connect(self.path)
        c.execute("PRAGMA journal_mode=WAL")
        return c

    def _init(self):
        with self._conn() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS documents(
              id INTEGER PRIMARY KEY, url TEXT UNIQUE, title TEXT, content_hash TEXT,
              added_at TEXT, updated_at TEXT, chars INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS chunks(
              id INTEGER PRIMARY KEY, document_id INTEGER, chunk_index INTEGER,
              text TEXT, FOREIGN KEY(document_id) REFERENCES documents(id)
            );
            CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(document_id);
            CREATE TABLE IF NOT EXISTS learning_events(
              id INTEGER PRIMARY KEY, kind TEXT, payload TEXT, created_at TEXT, status TEXT DEFAULT 'new'
            );
            """)

    @staticmethod
    def _tokens(text):
        return set(TOKEN_RE.findall((text or '').lower()))

    def add_document(self, url, title, text, chunk_size=1800):
        text = ' '.join((text or '').split()).strip()
        if not text:
            return {"added": False, "reason": "empty"}
        digest = hashlib.sha256(text.encode('utf-8', errors='ignore')).hexdigest()
        now = datetime.now().isoformat(timespec='seconds')
        with self._conn() as c:
            old = c.execute("SELECT id, content_hash FROM documents WHERE url=?", (url,)).fetchone()
            if old and old[1] == digest:
                return {"added": False, "reason": "unchanged", "document_id": old[0]}
            if old:
                doc_id = old[0]
                c.execute("UPDATE documents SET title=?, content_hash=?, updated_at=?, chars=? WHERE id=?",
                          (title or url, digest, now, len(text), doc_id))
                c.execute("DELETE FROM chunks WHERE document_id=?", (doc_id,))
            else:
                cur = c.execute("INSERT INTO documents(url,title,content_hash,added_at,updated_at,chars) VALUES(?,?,?,?,?,?)",
                                (url, title or url, digest, now, now, len(text)))
                doc_id = cur.lastrowid
            chunks = [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]
            c.executemany("INSERT INTO chunks(document_id,chunk_index,text) VALUES(?,?,?)",
                          [(doc_id, i, chunk) for i, chunk in enumerate(chunks)])
        return {"added": True, "reason": "updated" if old else "new", "document_id": doc_id, "chunks": len(chunks)}

    def search(self, query, limit=5):
        q = self._tokens(query)
        if not q:
            return []
        with self._conn() as c:
            rows = c.execute("SELECT chunks.text, documents.url, documents.title FROM chunks JOIN documents ON documents.id=chunks.document_id").fetchall()
        scored=[]
        for text,url,title in rows:
            t=self._tokens(text)
            overlap=len(q & t)
            if overlap:
                score=overlap / max(1, len(q))
                scored.append((score, text, url, title))
        scored.sort(key=lambda x:x[0], reverse=True)
        return [{"score":round(s,4),"text":t,"url":u,"title":ti} for s,t,u,ti in scored[:max(1,int(limit))]]

    def stats(self):
        with self._conn() as c:
            docs=c.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
            chunks=c.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        return {"documents":docs,"chunks":chunks}

    def recent(self, limit=20):
        with self._conn() as c:
            return c.execute("SELECT url,title,updated_at,chars FROM documents ORDER BY updated_at DESC LIMIT ?",(int(limit),)).fetchall()
