
import json
import re
import random
import numpy as np
from pathlib import Path
from .paths import data_root

TOKEN_RE = re.compile(r"[a-záàâãéêíóôõúç0-9_]+")

SEED = [
    ("saudacao", "oi", "Olá! Eu sou o Fynix. ⚡"),
    ("saudacao", "olá", "Fala! O Fynix está online. 🤖"),
    ("saudacao", "e ai", "E aí! Bora trabalhar. 😎"),
    ("saudacao", "bom dia", "Bom dia! O que vamos construir hoje?"),
    ("saudacao", "boa noite", "Boa noite! Tô pronto para ajudar."),
    ("capacidades", "o que você faz", "Eu posso trabalhar com memória, arquivos, projetos e ferramentas locais."),
    ("capacidades", "quais são suas funções", "Minha base atual inclui memória, arquivos, configurações e um cérebro local experimental."),
    ("roblox", "roblox", "Posso analisar scripts e projetos Roblox pelo workspace configurado."),
    ("roblox", "roblox studio", "O Fynix pode ser preparado para uma ponte com o Roblox Studio."),
    ("roblox", "luau", "Luau é uma das minhas áreas de treinamento inicial."),
    ("programacao", "python", "Python está entre minhas áreas de treinamento inicial."),
    ("programacao", "javascript", "JavaScript está entre minhas áreas de treinamento inicial."),
    ("programacao", "programar", "Posso ajudar a analisar código e organizar tarefas de programação."),
    ("memoria", "lembre disso", "Posso salvar essa informação na minha memória persistente."),
    ("memoria", "você lembra", "Minha memória local guarda fatos e preferências salvos pelo usuário."),
    ("auto", "se autoaprimorar", "Meu modo de autoaprimoramento pode treinar novas amostras e criar uma nova versão do cérebro."),
    ("auto", "melhore você mesmo", "Posso analisar meu desempenho, propor melhorias e treinar uma nova versão."),
    ("internet", "pesquise na internet", "Posso usar o Web Worker local para colocar pesquisas na fila, conforme a permissão estiver ativa."),
    ("recursos", "quanto de ram", "Posso monitorar a RAM usada pelo computador e o limite configurado para minhas tarefas."),
    ("recursos", "cpu", "Posso monitorar a CPU e configurar afinidade quando o Windows permitir."),
    ("personalidade", "mude sua personalidade", "Minha personalidade pode ser ajustada no painel de configurações."),
    ("despedida", "tchau", "Até mais! O Fynix continua pronto na bandeja. 👋"),
    ("despedida", "valeu", "Tamo junto! ⚡"),
]

class FynixBrain:
    def __init__(self):
        self.dir = data_root() / "brain"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.model_path = self.dir / "model.npz"
        self.data_path = self.dir / "training.json"
        self.version_path = self.dir / "version.txt"
        self.examples = self._load_examples()
        self.version = self.version_path.read_text(encoding="utf-8").strip() if self.version_path.exists() else "0.1"
        self.W = None
        self.b = None
        self.vocab = {}
        self.labels = []
        self.ready = False
        self.train()

    def _load_examples(self):
        examples = list(SEED)
        if self.data_path.exists():
            try:
                extra = json.loads(self.data_path.read_text(encoding="utf-8"))
                examples.extend(extra)
            except Exception:
                pass
        return examples

    @staticmethod
    def tokenize(text):
        return TOKEN_RE.findall(text.lower())

    def _build(self):
        vocab_tokens = sorted(set(t for _, text, _ in self.examples for t in self.tokenize(text)))
        self.vocab = {t:i for i,t in enumerate(vocab_tokens)}
        self.labels = sorted(set(lbl for lbl,_,_ in self.examples))
        label_index = {l:i for i,l in enumerate(self.labels)}
        X = np.zeros((len(self.examples), len(self.vocab)), dtype=np.float32)
        y = np.zeros(len(self.examples), dtype=np.int64)
        for i,(lbl,text,_) in enumerate(self.examples):
            for t in set(self.tokenize(text)):
                if t in self.vocab:
                    X[i,self.vocab[t]] += 1.0
            y[i] = label_index[lbl]
        return X, y

    def train(self):
        X, y = self._build()
        rng = np.random.default_rng(42)
        n_in = X.shape[1]
        n_out = len(self.labels)
        hidden = min(48, max(16, n_in * 2))
        W1 = rng.normal(0, 0.08, size=(n_in, hidden)).astype(np.float32)
        b1 = np.zeros(hidden, dtype=np.float32)
        W2 = rng.normal(0, 0.08, size=(hidden, n_out)).astype(np.float32)
        b2 = np.zeros(n_out, dtype=np.float32)

        Y = np.zeros((len(y), n_out), dtype=np.float32)
        Y[np.arange(len(y)), y] = 1.0

        for _ in range(500):
            H = np.tanh(X @ W1 + b1)
            logits = H @ W2 + b2
            logits -= logits.max(axis=1, keepdims=True)
            P = np.exp(logits)
            P /= P.sum(axis=1, keepdims=True)

            dlog = (P - Y) / len(y)
            dW2 = H.T @ dlog
            db2 = dlog.sum(axis=0)
            dH = dlog @ W2.T
            dZ = dH * (1 - H*H)
            dW1 = X.T @ dZ
            db1 = dZ.sum(axis=0)

            lr = 0.15
            W1 -= lr * dW1
            b1 -= lr * db1
            W2 -= lr * dW2
            b2 -= lr * db2

        self.W = W1, W2
        self.b = b1, b2
        np.savez_compressed(
            self.model_path, W1=W1, b1=b1, W2=W2, b2=b2,
            vocab=json.dumps(self.vocab), labels=json.dumps(self.labels)
        )
        self.ready = True

    def predict(self, text):
        if not self.ready:
            self.train()
        x = np.zeros(len(self.vocab), dtype=np.float32)
        for t in set(self.tokenize(text)):
            if t in self.vocab:
                x[self.vocab[t]] += 1.0
        W1,W2 = self.W
        b1,b2 = self.b
        h = np.tanh(x @ W1 + b1)
        logits = h @ W2 + b2
        logits -= logits.max()
        p = np.exp(logits)
        p /= p.sum()
        idx = int(np.argmax(p))
        return self.labels[idx], float(p[idx])

    def answer(self, text):
        label, conf = self.predict(text)
        candidates = [r for lbl,_,r in self.examples if lbl == label]
        response = random.choice(candidates) if candidates else "Ainda estou aprendendo."
        if conf < 0.52:
            return "Ainda estou aprendendo sobre isso. " + response, label, conf
        return response, label, conf

    def add_example(self, label, text, response):
        self.examples.append((label, text, response))
        current = []
        if self.data_path.exists():
            try:
                current = json.loads(self.data_path.read_text(encoding="utf-8"))
            except Exception:
                current = []
        current.append([label, text, response])
        self.data_path.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")

    def self_improve(self, new_examples):
        for label,text,response in new_examples:
            self.add_example(label,text,response)
        old = self.version
        parts = old.split(".")
        try:
            minor = int(parts[-1]) + 1
            self.version = ".".join(parts[:-1] + [str(minor)])
        except Exception:
            self.version = "0.1"
        self.train()
        self.version_path.write_text(self.version, encoding="utf-8")
        return old, self.version
