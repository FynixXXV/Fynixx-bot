
from PySide6.QtCore import Qt, QTimer
import json
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QLineEdit,
    QPushButton, QLabel, QFileDialog, QTabWidget, QFormLayout, QSpinBox, QSystemTrayIcon,
    QCheckBox, QComboBox, QMessageBox, QGroupBox, QListWidget, QDoubleSpinBox
)
from .agent import Agent
from .resources import snapshot
from .settings import SettingsStore
from .tray import TrayController
from .brain import FynixBrain
from .self_improvement import SelfImprovement
from .online_learning import OnlineLearner
from .webworker import WebWorker

class FynixWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Fynix AI — Local Brain")
        self.resize(1180, 780)
        self.setMinimumSize(950, 620)
        self.setStyleSheet("""
        QMainWindow,QWidget { background:#0e1218; color:#eef3f8; font-size:13px; }
        QTabWidget::pane { border:1px solid #2b3340; }
        QTabBar::tab { background:#171d26; padding:10px 14px; }
        QTabBar::tab:selected { background:#2b3950; }
        QLineEdit,QTextEdit,QListWidget,QComboBox,QSpinBox,QDoubleSpinBox {
            background:#171d26; color:#eef3f8; border:1px solid #343d4b; border-radius:6px; padding:7px;
        }
        QPushButton { background:#3168e9; color:white; border:0; border-radius:6px; padding:8px 14px; }
        QPushButton:hover { background:#4779ee; }
        QGroupBox { border:1px solid #343d4b; border-radius:7px; margin-top:8px; padding-top:14px; }
        """)
        self.settings = SettingsStore()
        self.config = self.settings.load()
        self.brain = FynixBrain()
        self.improver = SelfImprovement(self.brain)
        self.agent = Agent(self.brain, self.config)
        self.online = OnlineLearner(self.agent.knowledge)
        self._allow_close = False
        self.web_worker = None
        self.workspace_label = QLabel("Workspace: nenhum")
        self.build()
        self.tray = TrayController(self)
        self.tray.show()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_resources)
        self.timer.start(2000)
        if self.config.get("online_learning",False):
            self.learning_timer=QTimer(self); self.learning_timer.timeout.connect(self.learn_all); self.learning_timer.start(int(self.config.get("online_interval_min",60))*60*1000)
        self.update_resources()

    def build(self):
        tabs = QTabWidget()
        tabs.addTab(self.chat_tab(), "💬 Chat")
        tabs.addTab(self.brain_tab(), "🧠 Cérebro")
        tabs.addTab(self.personality_tab(), "🎭 Personalidade")
        tabs.addTab(self.resources_tab(), "🖥️ Recursos")
        tabs.addTab(self.permissions_tab(), "🔐 Permissões")
        tabs.addTab(self.project_tab(), "📁 Projeto")
        tabs.addTab(self.web_tab(), "🌐 Web")
        tabs.addTab(self.learning_tab(), "🧠 Aprendizagem")
        self.setCentralWidget(tabs)

    def chat_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        self.chat=QTextEdit(); self.chat.setReadOnly(True)
        self.chat.append("<b>⚡ Fynix:</b> Cérebro local próprio carregado.")
        self.chat.append(f"Versão do cérebro: <b>{self.brain.version}</b> — sem provedor de IA externo.")
        l.addWidget(self.chat)
        row=QHBoxLayout()
        self.input=QLineEdit(); self.input.setPlaceholderText("Digite para o Fynix...")
        self.input.returnPressed.connect(self.send)
        send=QPushButton("Enviar"); send.clicked.connect(self.send)
        l.addWidget(self.input); row.addWidget(send)
        l.addLayout(row)
        feedback=QHBoxLayout()
        up=QPushButton("👍 Melhorou"); down=QPushButton("👎 Não ajudou"); improve=QPushButton("🧬 Autoaprimorar")
        up.clicked.connect(lambda: self.feedback(True)); down.clicked.connect(lambda: self.feedback(False))
        improve.clicked.connect(self.auto_improve)
        feedback.addWidget(up); feedback.addWidget(down); feedback.addWidget(improve); l.addLayout(feedback)
        return w

    def send(self):
        text=self.input.text().strip()
        if not text: return
        self.chat.append(f"<b>Você:</b> {text}")
        try:
            ans,label,conf=self.agent.respond(text)
            self.last_interaction=(text,label,ans)
            self.chat.append(f"<b>Fynix:</b> {ans}<br><small>confiança: {conf:.0%}</small>")
        except Exception as exc:
            self.chat.append(f"<b>Fynix:</b> ❌ {exc}")
        self.input.clear()

    def feedback(self, positive):
        if not hasattr(self, "last_interaction"):
            return
        text,label,answer=self.last_interaction
        if positive:
            self.chat.append("✅ Feedback salvo. Posso usar esse exemplo no próximo autoaprimoramento.")
        else:
            self.chat.append("📝 Feedback negativo registrado para revisão.")
        self.agent.record_feedback(text,label,answer,positive)

    def auto_improve(self):
        examples=self.agent.improvement_examples()
        if not examples:
            self.chat.append("🧬 Nenhum exemplo novo aprovado para treinar ainda.")
            return
        old,new=self.improver.apply(examples)
        self.chat.append(f"🧬 Autoaprimoramento concluído: cérebro {old} → {new}.")
        self.chat.append(f"📚 {len(examples)} exemplos incorporados ao treinamento.")

    def brain_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        self.brain_info=QLabel()
        self.brain_info.setTextInteractionFlags(Qt.TextSelectableByMouse)
        l.addWidget(QLabel("🧠 Fynix Brain — modelo local experimental"))
        l.addWidget(self.brain_info)
        l.addWidget(QLabel(
            "Este cérebro é implementado no próprio projeto e treinado localmente com NumPy. "
            "Ele não envia o chat para outro provedor."
        ))
        rebuild=QPushButton("🔄 Recriar/treinar cérebro")
        rebuild.clicked.connect(self.retrain)
        l.addWidget(rebuild)
        return w

    def retrain(self):
        self.brain.train()
        self.brain_info.setText("Treinamento concluído. Versão atual: " + self.brain.version)
        self.chat.append("🧠 Cérebro local refeito com o conjunto de treinamento atual.")

    def personality_tab(self):
        w=QWidget(); f=QFormLayout(w)
        self.name=QLineEdit(self.config["name"])
        self.tone=QComboBox(); self.tone.addItems(["Descontraído","Amigável","Profissional","Técnico","Personalizado"])
        self.tone.setCurrentText(self.config["tone"])
        self.humor=QSpinBox(); self.humor.setRange(0,100); self.humor.setValue(self.config["humor"])
        self.detail=QSpinBox(); self.detail.setRange(0,100); self.detail.setValue(self.config["detail"])
        self.personality=QTextEdit(); self.personality.setPlainText(self.config["personality"])
        save=QPushButton("💾 Salvar")
        save.clicked.connect(self.save_settings)
        f.addRow("Nome:",self.name); f.addRow("Modo:",self.tone); f.addRow("Humor:",self.humor)
        f.addRow("Detalhamento:",self.detail); f.addRow("Personalidade:",self.personality); f.addRow(save)
        return w

    def resources_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        self.resource_label=QLabel(); l.addWidget(self.resource_label)
        g=QGroupBox("Controle desejado")
        f=QFormLayout(g)
        self.ram=QComboBox(); self.ram.addItems(["2 GB","4 GB","8 GB","12 GB","Máximo disponível"]); self.ram.setCurrentText(self.config["ram_limit"])
        self.cpu=QSpinBox(); self.cpu.setRange(1,100); self.cpu.setValue(self.config["cpu_limit"]); self.cpu.setSuffix(" %")
        self.disk=QSpinBox(); self.disk.setRange(1,10000); self.disk.setValue(self.config["disk_limit_gb"]); self.disk.setSuffix(" GB")
        self.gpu=QComboBox(); self.gpu.addItems(["Automática"] + snapshot()["gpus"]); self.gpu.setCurrentText(self.config.get("gpu","Automática"))
        save=QPushButton("💾 Salvar recursos"); save.clicked.connect(self.save_settings)
        f.addRow("RAM:",self.ram); f.addRow("CPU meta:",self.cpu); f.addRow("Armazenamento:",self.disk); f.addRow("GPU:",self.gpu); f.addRow(save)
        l.addWidget(g)
        l.addWidget(QLabel("Os limites exatos são dependentes do Windows/driver. O Fynix não altera o sistema para forçar números impossíveis."))
        return w

    def permissions_tab(self):
        w=QWidget(); f=QFormLayout(w)
        self.box={}
        items=[("🌐 Internet","internet"),("📁 Arquivos","files"),("🎤 Microfone","microphone"),
               ("📷 Câmera","camera"),("🖥️ Executar programas","run_programs"),
               ("🗑️ Ações destrutivas sem confirmação","destructive_without_confirmation"),
               ("🎮 Roblox Studio Bridge","roblox_bridge")]
        for label,key in items:
            cb=QCheckBox(); cb.setChecked(bool(self.config.get(key,False))); self.box[key]=cb; f.addRow(label,cb)
        dev=QCheckBox("🛠️ Modo desenvolvedor — configuração ampla")
        dev.setChecked(bool(self.config.get("developer_mode",True))); self.box["developer_mode"]=dev; f.addRow(dev)
        save=QPushButton("💾 Salvar permissões"); save.clicked.connect(self.save_settings); f.addRow(save)
        f.addRow(QLabel("O modo desenvolvedor não ignora UAC ou permissões do Windows."))
        return w

    def project_tab(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.workspace_label)
        choose=QPushButton("📂 Escolher qualquer pasta"); choose.clicked.connect(self.choose_workspace); l.addWidget(choose)
        self.files=QListWidget(); l.addWidget(self.files)
        refresh=QPushButton("🔄 Atualizar"); refresh.clicked.connect(self.refresh_files); l.addWidget(refresh)
        return w

    def choose_workspace(self):
        folder=QFileDialog.getExistingDirectory(self,"Escolher workspace")
        if folder:
            self.agent.set_workspace(folder)
            self.workspace_label.setText("Workspace: "+folder)
            self.refresh_files()

    def refresh_files(self):
        self.files.clear()
        for p in self.agent.workspace.list_files():
            self.files.addItem(str(p))

    def web_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        l.addWidget(QLabel("🌐 Web Worker — consulta de páginas autorizadas"))
        self.url_input=QLineEdit(); self.url_input.setPlaceholderText("https://exemplo.com")
        go=QPushButton("Ler URL"); go.clicked.connect(self.start_web)
        learn=QPushButton("📚 Aprender esta URL"); learn.clicked.connect(self.learn_url)
        self.web_out=QTextEdit(); self.web_out.setReadOnly(True)
        l.addWidget(self.url_input); l.addWidget(go); l.addWidget(learn); l.addWidget(self.web_out)
        return w

    def start_web(self):
        """Lê uma URL em segundo plano e mostra o texto extraído.

        O método existia na interface visual esperada pela V2, mas havia sido
        omitido durante a integração da V3. Mantemos a leitura separada do
        recurso de aprendizagem: aqui apenas exibimos o conteúdo; o botão
        "Aprender esta URL" é o responsável por persistir o conhecimento.
        """
        url = self.url_input.text().strip()
        if not url:
            self.web_out.setPlainText("Digite uma URL primeiro.")
            return
        if not self.config.get("internet", True):
            self.web_out.setPlainText("Internet desativada nas permissões.")
            return

        if self.web_worker is not None and self.web_worker.isRunning():
            self.web_out.setPlainText("⏳ Já existe uma leitura Web em andamento.")
            return

        self.web_out.setPlainText("🌐 Lendo página... aguarde.")
        self.web_worker = WebWorker([url])
        self.web_worker.result.connect(self.on_web_result)
        self.web_worker.finished.connect(self.on_web_finished)
        self.web_worker.start()

    def on_web_result(self, url, text):
        if text.startswith("ERRO:"):
            self.web_out.setPlainText(f"❌ {url}\n{text}")
            return
        self.web_out.setPlainText(
            f"🌐 URL: {url}\n\n"
            f"Conteúdo extraído ({len(text):,} caracteres):\n\n{text}"
        )

    def on_web_finished(self):
        self.web_worker = None

    def learning_tab(self):
        w=QWidget(); l=QVBoxLayout(w)
        self.learning_status=QLabel()
        l.addWidget(QLabel("🧠 Aprendizagem online e memória de conhecimento")); l.addWidget(self.learning_status)
        self.source_input=QLineEdit(); self.source_input.setPlaceholderText("URL para acompanhar automaticamente")
        add=QPushButton("➕ Adicionar fonte"); add.clicked.connect(self.add_learning_source)
        l.addWidget(self.source_input); l.addWidget(add)
        self.sources_list=QListWidget(); l.addWidget(self.sources_list)
        self.learn_now_btn=QPushButton("🌐 Aprender agora"); self.learn_now_btn.clicked.connect(self.learn_all)
        l.addWidget(self.learn_now_btn)
        self.auto_learning=QCheckBox("🔄 Aprendizagem online automática")
        self.auto_learning.setChecked(bool(self.config.get('online_learning',False)))
        self.auto_learning.toggled.connect(self.toggle_online_learning)
        l.addWidget(self.auto_learning)
        l.addWidget(QLabel("Por segurança, a Web só alimenta a base de conhecimento. Feedback negativo não altera o cérebro automaticamente."))
        self.refresh_learning()
        return w

    def add_learning_source(self):
        try:
            n=self.online.add_source(self.source_input.text().strip())
            self.source_input.clear(); self.refresh_learning()
            self.web_out.setPlainText(f"Fonte adicionada. Total: {n}")
        except Exception as exc: QMessageBox.warning(self,'Fonte inválida',str(exc))

    def learn_url(self):
        try:
            r=self.online.learn_url(self.url_input.text().strip())
            self.web_out.setPlainText(f"📚 Aprendizagem: {r}")
            self.refresh_learning()
        except Exception as exc: self.web_out.setPlainText(f"❌ {exc}")

    def learn_all(self):
        if not self.config.get('internet',True):
            self.web_out.setPlainText('Internet desativada nas permissões.'); return
        self.web_out.setPlainText(json.dumps(self.online.learn_all(),ensure_ascii=False,indent=2))
        self.refresh_learning()

    def refresh_learning(self):
        if not hasattr(self,'sources_list'): return
        self.sources_list.clear()
        for u in self.online.sources(): self.sources_list.addItem(u)
        st=self.online.knowledge.stats(); fb=self.agent.learning.stats()
        self.learning_status.setText(f"Documentos: {st['documents']} | Blocos: {st['chunks']} | Feedback: {fb['total']} (👍 {fb['positive']} / 👎 {fb['negative']})")

    def toggle_online_learning(self, enabled):
        self.config['online_learning']=bool(enabled)
        self.settings.save(self.config)
        if enabled and not hasattr(self,'learning_timer'):
            self.learning_timer=QTimer(self); self.learning_timer.timeout.connect(self.learn_all)
        if enabled:
            if not hasattr(self,'learning_timer'): return
            self.learning_timer.start(int(self.config.get('online_interval_min',60))*60*1000)
        elif hasattr(self,'learning_timer'):
            self.learning_timer.stop()

    def save_settings(self):
        self.config.update({
            "name": self.name.text(),
            "tone": self.tone.currentText(),
            "humor": self.humor.value(),
            "detail": self.detail.value(),
            "personality": self.personality.toPlainText(),
            "ram_limit": self.ram.currentText(),
            "cpu_limit": self.cpu.value(),
            "disk_limit_gb": self.disk.value(),
            "gpu": self.gpu.currentText(),
            "background_on_close": self.config.get("background_on_close",True),
            "online_learning": getattr(self,"auto_learning",None).isChecked() if hasattr(self,"auto_learning") else self.config.get("online_learning",False),
        })
        for k,b in getattr(self,"box",{}).items(): self.config[k]=b.isChecked()
        self.settings.save(self.config)
        self.agent.config=self.config
        QMessageBox.information(self,"Fynix AI","✅ Configurações salvas.")

    def update_resources(self):
        try:
            s=snapshot()
            self.resource_label.setText(
                f"CPU: {s['cpu_percent']:.0f}%\n"
                f"RAM: {s['ram_used']:.2f}/{s['ram_total']:.2f} GB ({s['ram_percent']:.0f}%)\n"
                f"CPU lógicas: {s['cpu_count']}\n"
                f"Disco livre: {s['disk_free']:.1f}/{s['disk_total']:.1f} GB\n"
                f"GPU detectada: {', '.join(s['gpus']) if s['gpus'] else 'não detectada'}"
            )
            self.brain_info.setText(
                f"Versão: {self.brain.version}\n"
                f"Exemplos de treinamento: {len(self.brain.examples)}\n"
                f"Vocabulário: {len(self.brain.vocab)} tokens\n"
                f"Classes: {len(self.brain.labels)}"
            )
        except Exception as exc:
            self.resource_label.setText(str(exc))

    def closeEvent(self,event):
        if self.config.get("background_on_close",True) and not self._allow_close:
            self.hide()
            self.tray.tray.showMessage("Fynix AI","O Fynix continua em segundo plano.",QSystemTrayIcon.Information,2200)
            event.ignore()
        else:
            event.accept()
