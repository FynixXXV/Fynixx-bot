from .memory import MemoryStore
from .workspace import Workspace
from .paths import data_root
from .knowledge import KnowledgeStore
from .learning import ContinuousLearning

class Agent:
    def __init__(self, brain, config):
        self.brain=brain; self.config=config; self.memory=MemoryStore(); self.workspace=Workspace()
        self.knowledge=KnowledgeStore(); self.learning=ContinuousLearning()

    def set_workspace(self,folder): self.workspace.set_root(folder)

    def respond(self,message):
        low=message.lower().strip()
        if low in ('/help','/ajuda'):
            return ('Comandos: /help, /memoria, /arquivos, /ler <arquivo>, /lembrar <texto>, /conhecimento <busca>, /autoaprimorar'), 'ajuda', 1.0
        if low=='/memoria': return str(self.memory.load()),'memoria',1.0
        if low=='/arquivos':
            fs=self.workspace.list_files(); return ('\n'.join(map(str,fs[:100])) if fs else 'Nenhum arquivo no workspace.'),'arquivos',1.0
        if low.startswith('/lembrar '):
            self.memory.add_fact(message[10:].strip()); return '✅ Salvei essa informação na minha memória.','memoria',1.0
        if low.startswith('/ler '):
            try: return self.workspace.read_text(message[5:].strip())[:12000],'arquivos',1.0
            except Exception as exc: return f'❌ {exc}','arquivos',1.0
        if low.startswith('/conhecimento '):
            hits=self.knowledge.search(message[14:].strip(),5)
            if not hits: return 'Não encontrei conhecimento relevante na base local.','conhecimento',0.0
            return '\n\n'.join(f"📚 {h['title']}\n{h['text'][:900]}\nFonte: {h['url']}" for h in hits),'conhecimento',hits[0]['score']
        if low=='/autoaprimorar': return 'Use o botão 🧬 Autoaprimorar depois de fornecer feedback.','auto',1.0
        ans,label,conf=self.brain.answer(message)
        hits=self.knowledge.search(message,2) if self.config.get('knowledge_retrieval',True) else []
        if hits and conf<0.75:
            ans += '\n\n📚 Encontrei material relacionado na minha base de conhecimento:\n'
            ans += '\n'.join(f"• {h['text'][:500]}\n  Fonte: {h['url']}" for h in hits)
        tone=self.config.get('tone','Descontraído')
        if tone=='Profissional': ans=ans.replace('Fala!','Olá!')
        elif tone=='Técnico': ans += '\n\n[modo técnico]'
        return ans,label,conf

    def record_feedback(self,text,label,answer,positive):
        return self.learning.record(text,label,answer,positive)

    def improvement_examples(self): return self.learning.approved_examples()
