
import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication, QMessageBox
from app.ui import FynixWindow
from app.paths import ensure_dirs

def log_error(exc):
    p = ensure_dirs() / "logs" / "startup_error.log"
    with p.open("a", encoding="utf-8") as f:
        import traceback
        f.write("\n" + "="*80 + "\n")
        f.write(traceback.format_exc())
    return p

def main():
    try:
        ensure_dirs()
        app = QApplication(sys.argv)
        app.setApplicationName("Fynix AI")
        app.setApplicationDisplayName("Fynix AI")
        app.setOrganizationName("Fynix")
        window = FynixWindow()
        window.show()
        return app.exec()
    except Exception as exc:
        log = log_error(exc)
        try:
            QMessageBox.critical(
                None, "Fynix AI - erro",
                f"O Fynix não conseguiu iniciar.\n\n{exc}\n\nLog:\n{log}"
            )
        except Exception:
            pass
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
