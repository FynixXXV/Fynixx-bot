@echo off
setlocal
cd /d "%~dp0"

py -m pip install -r requirements.txt || goto :error
py -m pip install pyinstaller || goto :error

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

pyinstaller --noconfirm --clean --windowed --onedir --uac-admin --name FynixAI main.py

if errorlevel 1 goto :error

echo.
echo Fynix AI compilado com sucesso!
echo EXE: %CD%\dist\FynixAI\FynixAI.exe
pause
exit /b 0

:error
echo.
echo Falha durante o build.
pause
exit /b 1
