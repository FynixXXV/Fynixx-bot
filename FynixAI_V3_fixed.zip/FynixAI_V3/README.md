# Fynix AI V3 — Online Learning + Knowledge Memory

V3 mantém o cérebro local experimental e adiciona uma camada de conhecimento persistente.

## Novidades
- Base SQLite de conhecimento (`knowledge.db`).
- Busca local determinística por termos.
- Aprendizagem online de URLs adicionadas pelo usuário.
- Atualização automática periódica opcional.
- Bloqueio básico de hosts locais/privados para evitar SSRF acidental.
- Feedback contínuo auditável: positivo pode entrar no pipeline de treino; negativo fica como revisão.
- Eventos em `learning_events.jsonl` para integração com o Evolution Center.
- Recuperação de conhecimento durante respostas de baixa confiança.
- Configurações para ativar/desativar aprendizagem online.

## Importante
O sistema não "baixa uma IA nova" da internet nem executa código encontrado em páginas. Conteúdo web vira dados de conhecimento; mudanças de código passam pelo Evolution Center.

## Execução
```powershell
py -m pip install -r requirements.txt
py main.py
```
